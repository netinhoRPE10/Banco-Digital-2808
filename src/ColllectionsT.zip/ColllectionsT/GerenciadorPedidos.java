package ColllectionsT;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class GerenciadorPedidos {
    private Map<String, Pedido> pedidos = new HashMap<>();
    private Set<Produto> catalogoProdutos = new HashSet<>();
    // Adiciona um produto ao catálogo (usa Set para garantir unicidade)
    public void adicionarProdutoCatalogo(Produto produto) {
        catalogoProdutos.add(produto);
        System.out.println("Produto '" + produto.getNome() + "' adicionado ao catálogo.");
    }
    // Registra um novo pedido (usa Map e List)
    public void registrarNovoPedido(String idPedido, List<String> idsProdutos) {
        // Usa uma lista temporária para armazenar os objetos Produto
        List<Produto> produtosDoPedido = new ArrayList<>();

        // Valida se todos os produtos existem no catálogo (usa o Set)
        for (String idProduto : idsProdutos) {
            Produto produtoEncontrado = encontrarProdutoNoCatalogo(idProduto);
            if (produtoEncontrado == null) {
                System.out.println("Erro: O produto com ID '" + idProduto + "' não foi encontrado no catálogo. Pedido '" + idPedido + "' rejeitado.");
                return; // Aborta o registro do pedido
            }
            produtosDoPedido.add(produtoEncontrado);
        }
        // Se a validação passar, cria o pedido e o adiciona ao Map
        Pedido novoPedido = new Pedido(idPedido, produtosDoPedido);
        pedidos.put(idPedido, novoPedido);
        System.out.println("Pedido '" + idPedido + "' registrado com sucesso!");
    }
    // Método auxiliar para encontrar um produto no catálogo
    private Produto encontrarProdutoNoCatalogo(String idProduto) {
        // Itera sobre o Set para encontrar o produto pelo ID
        for (Produto produto : catalogoProdutos) {
            if (produto.getId().equals(idProduto)) {
                return produto;
            }
        }
        return null;
    }
    // Atualiza o status de um pedido (usa o Map para acesso rápido)
    public void atualizarStatusPedido(String idPedido, String novoStatus) {
        Pedido pedido = pedidos.get(idPedido);
        if (pedido != null) {
            pedido.setStatus(novoStatus);
            System.out.println("Status do pedido '" + idPedido + "' atualizado para '" + novoStatus + "'.");
        } else {
            System.out.println("Erro: Pedido com ID '" + idPedido + "' não encontrado.");
        }
    }

    // Exibe um resumo de todos os pedidos (itera sobre o Map)
    public void exibirResumoPedidos() {
        System.out.println("\n--- Resumo de Todos os Pedidos ---");
        if (pedidos.isEmpty()) {
            System.out.println("Nenhum pedido registrado.");
            return;
        }

        // Itera sobre os valores do Map
        for (Pedido pedido : pedidos.values()) {
            System.out.println("ID do Pedido: " + pedido.getId());
            System.out.println("Status: " + pedido.getStatus());
            System.out.println("Produtos:");

            // Itera sobre a lista de produtos de cada pedido
            for (Produto produto : pedido.getProdutos()) {
                System.out.println("  - " + produto.getNome() + " (ID: " + produto.getId() + ")");
            }
            System.out.println("---------------------------------");
        }
    }
}