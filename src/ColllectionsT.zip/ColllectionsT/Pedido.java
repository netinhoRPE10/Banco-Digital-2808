package ColllectionsT;

import java.util.List;

public class Pedido {
    private String id;
    private List<Produto> produtos;
    private String status;
    public Pedido(String id, List<Produto> produtos) {
        this.id = id;
        this.produtos = produtos;
        this.status = "PENDENTE";
    }
    public String getId() {
        return id;
    }
    public List<Produto> getProdutos() {
        return produtos;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
}