package ColllectionsT;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        GerenciadorPedidos gerenciador = new GerenciadorPedidos();

        // 1. Adicionar produtos ao catálogo (usa Set)
        System.out.println("--- Adicionando produtos ao catálogo ---");
        gerenciador.adicionarProdutoCatalogo(new Produto("P001", "Smartphone X"));
        gerenciador.adicionarProdutoCatalogo(new Produto("P002", "Smart TV 55\""));
        gerenciador.adicionarProdutoCatalogo(new Produto("P003", "Fone de Ouvido sem Fio"));
        gerenciador.adicionarProdutoCatalogo(new Produto("P004", "Mouse Gamer"));
        System.out.println("\n");

        // 2. Registrar novos pedidos (usa Map e valida com Set)
        System.out.println("--- Registrando pedidos ---");
        // Pedido válido
        List<String> produtosPedido1 = Arrays.asList("P001", "P003");
        gerenciador.registrarNovoPedido("PED-123", produtosPedido1);

        // Pedido com produto inválido (deve ser rejeitado)
        List<String> produtosPedido2 = Arrays.asList("P001", "P999", "P004");
        gerenciador.registrarNovoPedido("PED-456", produtosPedido2);

        // Outro pedido válido
        List<String> produtosPedido3 = Arrays.asList("P002", "P004");
        gerenciador.registrarNovoPedido("PED-789", produtosPedido3);
        System.out.println("\n");

        // 3. Exibir resumo inicial dos pedidos
        gerenciador.exibirResumoPedidos();

        // 4. Atualizar o status de um pedido (usa Map)
        System.out.println("\n--- Atualizando status de um pedido ---");
        gerenciador.atualizarStatusPedido("PED-123", "PROCESSANDO");
        gerenciador.atualizarStatusPedido("PED-789", "ENTREGUE");

        // Tentativa de atualizar um pedido inexistente
        gerenciador.atualizarStatusPedido("PED-000", "CANCELADO");
        System.out.println("\n");

        // 5. Exibir resumo final dos pedidos
        gerenciador.exibirResumoPedidos();
    }
}